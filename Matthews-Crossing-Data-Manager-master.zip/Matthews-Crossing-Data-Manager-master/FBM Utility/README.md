## FBM Utility

Utiity functions to access FBM's database