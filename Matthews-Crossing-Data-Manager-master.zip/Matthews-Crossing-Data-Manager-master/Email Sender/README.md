## Email Sender

Functions to get send emails to donors as well as thank you notes

Backend functions exist in FBA, but we were unable to get API access to there system to implment
